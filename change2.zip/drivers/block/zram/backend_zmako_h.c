#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <asm/unaligned.h>

#include "backend_zmako_h.h"

#define DICT_SIZE 256
#define DICT_MASK 0xFF
#define HASH_MULTIPLIER 0x9E3779B185EBCA87ULL

static const u8 payload_step[4] = {0, 1, 4, 8};

static void zmako_h_release_params(struct zcomp_params *params) {}
static int zmako_h_setup_params(struct zcomp_params *params) { return 0; }
static void zmako_h_destroy(struct zcomp_ctx *ctx) {}

static int zmako_h_create(struct zcomp_params *params, struct zcomp_ctx *ctx)
{
	ctx->context = NULL;
	return 0;
}

static int zmako_h_compress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			  struct zcomp_req *req)
{
	const u64 *src_words = (const u64 *)req->src;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	u64 *tags_out = (u64 *)req->dst;
	u8 *payload_base = req->dst + tag_area_size;

	u32 payload_offset = 0;
	u64 current_tags = 0;
	int tag_shift = 0;

	u64 dict[257] = {0};

	for (int i = 0; i < words_per_page; i++) {
		u64 word = src_words[i];
		u8 hash = (word * HASH_MULTIPLIER) >> 56;
		u64 d_word = dict[hash];

		bool is_zero  = (word == 0);
		bool is_exact = (d_word == word);
		bool is_small = ((word >> 32) == 0);

		u8 state = is_zero ? 0 : (is_exact ? 1 : (is_small ? 2 : 3));

		u64 out_val = (state == 3) ? word :
			      (state == 2) ? (u32)word :
			      (state == 1) ? hash : 0;

		put_unaligned(out_val, (u64 *)(payload_base + payload_offset));
		payload_offset += payload_step[state];

		u32 update_idx = (state == 0) ? 256 : hash;
		dict[update_idx] = word;

		current_tags |= ((u64)state << tag_shift);
		tag_shift += 2;

		if (unlikely(tag_shift == 64)) {
			*tags_out++ = current_tags;
			current_tags = 0;
			tag_shift = 0;
		}
	}

	req->dst_len = tag_area_size + payload_offset;
	return 0;
}

static int zmako_h_decompress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			    struct zcomp_req *req)
{
	u64 *dst_words = (u64 *)req->dst;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	const u64 *tags_in = (const u64 *)req->src;
	const u8 *payload = req->src + tag_area_size;

	u64 current_tags = 0;
	int tag_shift = 64;

	u64 dict[257] = {0};

	for (int i = 0; i < words_per_page; i++) {
		if (unlikely(tag_shift == 64)) {
			current_tags = *tags_in++;
			tag_shift = 0;
		}

		u8 state = (current_tags >> tag_shift) & 0x03;
		tag_shift += 2;

		u64 p_val = get_unaligned((const u64 *)payload);
		u8 hash = p_val & 0xFF;
		u64 d_val = dict[hash];

		u64 out_word = (state == 3) ? p_val :
			       (state == 2) ? (u32)p_val :
			       (state == 1) ? d_val : 0;

		dst_words[i] = out_word;

		u8 hash3 = (out_word * HASH_MULTIPLIER) >> 56;
		u32 update_idx = (state >= 2) ? hash3 :
				 (state == 0) ? 256 : hash;

		dict[update_idx] = out_word;

		payload += payload_step[state];
	}

	return 0;
}

const struct zcomp_ops backend_zmako_h = {
	.compress	= zmako_h_compress,
	.decompress	= zmako_h_decompress,
	.create_ctx	= zmako_h_create,
	.destroy_ctx	= zmako_h_destroy,
	.setup_params	= zmako_h_setup_params,
	.release_params	= zmako_h_release_params,
	.name		= "zmako_h",
};