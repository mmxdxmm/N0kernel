#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <asm/unaligned.h>
#include <linux/types.h>
#include <asm/neon.h>

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wbuiltin-macro-redefined"

#undef __INT64_TYPE__
#define __INT64_TYPE__ long long
#undef __UINT64_TYPE__
#define __UINT64_TYPE__ unsigned long long

#undef __SIZE_MAX__
#define __SIZE_MAX__ (~(size_t)0)
#undef __UINTPTR_MAX__
#define __UINTPTR_MAX__ ULONG_MAX

#include <arm_neon.h>
#pragma GCC diagnostic pop

#include "backend_zmako_h.h"

#define DICT_SIZE        258
#define HASH_MULTIPLIER  0x9E3779B185EBCA87ULL
#define HASH_SHIFT       57
#define BANK_SIZE        128
#define ZERO_SLOT        256

struct zmako_h_ctx {
    u64 dict[DICT_SIZE];
    u64 age_bmp[2];
};

static const u8 zmako_h_perm_tables[16][16] = {
    {255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255},
    {17,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255},
    {17,8,9,255,255,255,255,255,255,255,255,255,255,255,255,255},
    {8,9,10,11,12,13,14,15,255,255,255,255,255,255,255,255},
    {16,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255},
    {16,17,255,255,255,255,255,255,255,255,255,255,255,255,255,255},
    {16,17,8,9,255,255,255,255,255,255,255,255,255,255,255,255},
    {16,8,9,10,11,12,13,14,15,255,255,255,255,255,255,255},
    {16,0,1,255,255,255,255,255,255,255,255,255,255,255,255,255},
    {16,0,1,17,255,255,255,255,255,255,255,255,255,255,255,255},
    {16,0,1,17,8,9,255,255,255,255,255,255,255,255,255,255},
    {16,0,1,8,9,10,11,12,13,14,15,255,255,255,255,255},
    {0,1,2,3,4,5,6,7,255,255,255,255,255,255,255,255},
    {0,1,2,3,4,5,6,7,17,255,255,255,255,255,255,255},
    {0,1,2,3,4,5,6,7,17,8,9,255,255,255,255,255},
    {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}
};

static const u8 zmako_h_unperm_tables[16][16] = {
    {255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255},
    {255,255,255,255,255,255,255,255,0,255,255,255,255,255,255,255},
    {255,255,255,255,255,255,255,255,0,1,2,255,255,255,255,255},
    {255,255,255,255,255,255,255,255,0,1,2,3,4,5,6,7},
    {0,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255},
    {0,255,255,255,255,255,255,255,1,255,255,255,255,255,255,255},
    {0,255,255,255,255,255,255,255,1,2,3,255,255,255,255,255},
    {0,255,255,255,255,255,255,255,1,2,3,4,5,6,7,8},
    {0,1,2,255,255,255,255,255,255,255,255,255,255,255,255,255},
    {0,1,2,255,255,255,255,255,3,255,255,255,255,255,255,255},
    {0,1,2,255,255,255,255,255,3,4,5,255,255,255,255,255},
    {0,1,2,255,255,255,255,255,3,4,5,6,7,8,9,10},
    {0,1,2,3,4,5,6,7,255,255,255,255,255,255,255,255},
    {0,1,2,3,4,5,6,7,8,255,255,255,255,255,255,255},
    {0,1,2,3,4,5,6,7,8,9,10,255,255,255,255,255},
    {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}
};

static const u8 zmako_h_length_tables[16] = {
    0, 1, 3, 8, 1, 2, 4, 9, 3, 4, 6, 11, 8, 9, 11, 16
};

static inline u8 zmako_h_get_state(u64 w, const u64 *dict, u8 *out_idx)
{
    u64 z_mask = -(u64)(w == 0);
    u8 h7 = (u8)((w * HASH_MULTIPLIER) >> HASH_SHIFT);
    
    u64 d0 = dict[h7];
    u64 d1 = dict[h7 + BANK_SIZE];
    
    u64 eq0 = -(u64)(w == d0);
    u64 eq1 = -(u64)(w == d1);
    u64 has_eq = eq0 | eq1;
    
    u64 diff0 = w ^ d0;
    u64 diff1 = w ^ d1;
    u64 match0 = -(u64)(diff0 <= 0xFFFFULL);
    u64 match1 = -(u64)(diff1 <= 0xFFFFULL);
    u64 has_diff = (match0 | match1) & ~has_eq;
    
    u8 idx_eq  = (h7 & (u8)eq0) | ((h7 + BANK_SIZE) & (u8)eq1);
    u8 idx_dif = (h7 & (u8)match0) | ((h7 + BANK_SIZE) & (u8)match1);
    u8 idx = (idx_eq & (u8)has_eq) | (idx_dif & (u8)has_diff);
    
    *out_idx = idx;
    
    u8 s = 0;
    s |= (u8)(~z_mask & 1) * (has_eq ? 1 : (has_diff ? 2 : 3));
    return s;
}

static inline void zmako_h_update_dict(u64 w, u8 s, struct zmako_h_ctx *zctx)
{
    u8 h7 = (u8)((w * HASH_MULTIPLIER) >> HASH_SHIFT);
    u64 *dict = zctx->dict;
    
    u64 z_mask = -(u64)(s == 0);
    u8 bank = (u8)((zctx->age_bmp[h7 >> 6] >> (h7 & 63)) & 1);
    u8 slot = h7 + (bank * BANK_SIZE);
    u8 final_slot = (ZERO_SLOT & (u8)z_mask) | (slot & (u8)~z_mask);
    
    dict[final_slot] = w;
    
    zctx->age_bmp[h7 >> 6] ^= (1ULL << (h7 & 63));
}

static void zmako_h_release_params(struct zcomp_params *params) {}
static int zmako_h_setup_params(struct zcomp_params *params) { return 0; }

static void zmako_h_destroy(struct zcomp_ctx *ctx) 
{
    kfree(ctx->context);
    ctx->context = NULL;
}

static int zmako_h_create(struct zcomp_params *params, struct zcomp_ctx *ctx)
{
    struct zmako_h_ctx *zctx;
    zctx = kzalloc(sizeof(*zctx), GFP_KERNEL);
    if (!zctx)
        return -ENOMEM;
    ctx->context = zctx;
    return 0;
}

static int zmako_h_compress(struct zcomp_params *params, struct zcomp_ctx *ctx,
              struct zcomp_req *req)
{
    struct zmako_h_ctx *zctx = ctx->context;
    u64 *dict = zctx->dict;
    
    const u64 *src_words = (const u64 *)req->src;
    int words_per_page = PAGE_SIZE / 8;
    int tag_area_size = words_per_page * 2 / 8;

    u64 *tags_out = (u64 *)req->dst;
    u8 *payload_base = req->dst + tag_area_size;
    u32 payload_offset = 0;

    kernel_neon_begin();
    
    for (int i = 0; i < words_per_page; i += 32) {
        u64 current_tags = 0;

        for (int j = 0; j < 32; j += 4) {
            int idx = i + j;
            
            __builtin_prefetch(&src_words[idx + 16], 0, 1);
            __builtin_prefetch(payload_base + payload_offset + 128, 1, 1);

            u64 w0 = src_words[idx];
            u64 w1 = src_words[idx+1];
            u64 w2 = src_words[idx+2];
            u64 w3 = src_words[idx+3];

            u8 idx0, idx1, idx2, idx3;
            u8 s0 = zmako_h_get_state(w0, dict, &idx0);
            u8 s1 = zmako_h_get_state(w1, dict, &idx1);
            u8 s2 = zmako_h_get_state(w2, dict, &idx2);
            u8 s3 = zmako_h_get_state(w3, dict, &idx3);

            zmako_h_update_dict(w0, s0, zctx);
            zmako_h_update_dict(w1, s1, zctx);
            zmako_h_update_dict(w2, s2, zctx);
            zmako_h_update_dict(w3, s3, zctx);

            u8 cs01 = (s0 << 2) | s1;
            uint64x2_t w64_01 = vsetq_lane_u64(w0, vdupq_n_u64(0), 0);
            w64_01 = vsetq_lane_u64(w1, w64_01, 1);
            
            uint16_t hashes01 = idx0 | ((u16)idx1 << 8);
            uint8x16x2_t tab01 = {
                vreinterpretq_u8_u64(w64_01),
                vreinterpretq_u8_u16(vdupq_n_u16(hashes01))
            };
            vst1q_u8(payload_base + payload_offset,
                     vqtbl2q_u8(tab01, vld1q_u8(zmako_h_perm_tables[cs01])));
            payload_offset += zmako_h_length_tables[cs01];

            u8 cs23 = (s2 << 2) | s3;
            uint64x2_t w64_23 = vsetq_lane_u64(w2, vdupq_n_u64(0), 0);
            w64_23 = vsetq_lane_u64(w3, w64_23, 1);
            
            uint16_t hashes23 = idx2 | ((u16)idx3 << 8);
            uint8x16x2_t tab23 = {
                vreinterpretq_u8_u64(w64_23),
                vreinterpretq_u8_u16(vdupq_n_u16(hashes23))
            };
            vst1q_u8(payload_base + payload_offset,
                     vqtbl2q_u8(tab23, vld1q_u8(zmako_h_perm_tables[cs23])));
            payload_offset += zmako_h_length_tables[cs23];

            current_tags |= ((u64)s0 << (j * 2)) | ((u64)s1 << (j * 2 + 2)) | 
                            ((u64)s2 << (j * 2 + 4)) | ((u64)s3 << (j * 2 + 6));
        }
        
        *tags_out++ = current_tags;
    }
    kernel_neon_end();

    put_unaligned(0ULL, (u64 *)(payload_base + payload_offset));
    put_unaligned(0ULL, (u64 *)(payload_base + payload_offset + 8));
    
    req->dst_len = tag_area_size + payload_offset + 16;
    return 0;
}

static int zmako_h_decompress(struct zcomp_params *params, struct zcomp_ctx *ctx,
                struct zcomp_req *req)
{
    struct zmako_h_ctx *zctx = ctx->context;
    u64 *dict = zctx->dict;
    
    u64 *dst_words = (u64 *)req->dst;
    int words_per_page = PAGE_SIZE / 8;
    int tag_area_size = words_per_page * 2 / 8;

    const u64 *tags_in = (const u64 *)req->src;
    const u8 *payload = req->src + tag_area_size;

    kernel_neon_begin();
    
    for (int i = 0; i < words_per_page; i += 32) {
        u64 current_tags = *tags_in++;

        for (int j = 0; j < 32; j += 4) {
            int idx = i + j;
            
            __builtin_prefetch(payload + 64, 0, 1);
            __builtin_prefetch(dst_words + idx + 16, 1, 1);

            u8 s0 = (current_tags >> (j * 2)) & 0x03;
            u8 s1 = (current_tags >> (j * 2 + 2)) & 0x03;
            u8 s2 = (current_tags >> (j * 2 + 4)) & 0x03;
            u8 s3 = (current_tags >> (j * 2 + 6)) & 0x03;

            u8 cs01 = (s0 << 2) | s1;
            uint8x16_t unpacked01 = vqtbl1q_u8(
                vld1q_u8(payload),
                vld1q_u8(zmako_h_unperm_tables[cs01])
            );
            payload += zmako_h_length_tables[cs01];
            uint64x2_t u64_01 = vreinterpretq_u64_u8(unpacked01);
            u64 w0_raw = vgetq_lane_u64(u64_01, 0);
            u64 w1_raw = vgetq_lane_u64(u64_01, 1);

            u8 cs23 = (s2 << 2) | s3;
            uint8x16_t unpacked23 = vqtbl1q_u8(
                vld1q_u8(payload),
                vld1q_u8(zmako_h_unperm_tables[cs23])
            );
            payload += zmako_h_length_tables[cs23];
            uint64x2_t u64_23 = vreinterpretq_u64_u8(unpacked23);
            u64 w2_raw = vgetq_lane_u64(u64_23, 0);
            u64 w3_raw = vgetq_lane_u64(u64_23, 1);

            u64 d0 = dict[w0_raw & 0xFF];
            u64 out0 = (s0 == 3) ? w0_raw :
                       (s0 == 2) ? ((d0 & ~0xFFFFULL) | ((w0_raw >> 8) & 0xFFFF)) :
                       (s0 == 1) ? d0 : 0;
            
            u64 d1 = dict[w1_raw & 0xFF];
            u64 out1 = (s1 == 3) ? w1_raw :
                       (s1 == 2) ? ((d1 & ~0xFFFFULL) | ((w1_raw >> 8) & 0xFFFF)) :
                       (s1 == 1) ? d1 : 0;
            
            u64 d2 = dict[w2_raw & 0xFF];
            u64 out2 = (s2 == 3) ? w2_raw :
                       (s2 == 2) ? ((d2 & ~0xFFFFULL) | ((w2_raw >> 8) & 0xFFFF)) :
                       (s2 == 1) ? d2 : 0;
            
            u64 d3 = dict[w3_raw & 0xFF];
            u64 out3 = (s3 == 3) ? w3_raw :
                       (s3 == 2) ? ((d3 & ~0xFFFFULL) | ((w3_raw >> 8) & 0xFFFF)) :
                       (s3 == 1) ? d3 : 0;

            dst_words[idx] = out0;
            dst_words[idx+1] = out1;
            dst_words[idx+2] = out2;
            dst_words[idx+3] = out3;

            zmako_h_update_dict(out0, s0, zctx);
            zmako_h_update_dict(out1, s1, zctx);
            zmako_h_update_dict(out2, s2, zctx);
            zmako_h_update_dict(out3, s3, zctx);
        }
    }
    kernel_neon_end();

    return 0;
}

const struct zcomp_ops backend_zmako_h = {
    .compress    = zmako_h_compress,
    .decompress  = zmako_h_decompress,
    .create_ctx  = zmako_h_create,
    .destroy_ctx = zmako_h_destroy,
    .setup_params= zmako_h_setup_params,
    .release_params = zmako_h_release_params,
    .name        = "zmako_h",
};
