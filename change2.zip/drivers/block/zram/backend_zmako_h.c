#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <asm/unaligned.h>
#include <linux/types.h>
#include <linux/prefetch.h>

#if defined(CONFIG_ARM64) || defined(__aarch64__)
#define USE_NEON_ZMAKO_H 1

#include <asm/neon.h>

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wbuiltin-macro-redefined"

#undef __INT64_TYPE__
#define __INT64_TYPE__ long long
#undef __UINT64_TYPE__
#define __UINT64_TYPE__ unsigned long long

#undef __SIZE_MAX__
#define __SIZE_MAX__ (~(size_t)0)
#undef __UINTPTR_MAX__
#define __UINTPTR_MAX__ ULONG_MAX

#include <arm_neon.h>

#pragma GCC diagnostic pop

#endif

#include "backend_zmako_h.h"

#define DICT_SIZE 256
#define DICT_MASK 0xFF
#define HASH_MULTIPLIER 0x9E3779B185EBCA87ULL
#define HASH_SHIFT 56

static const u8 payload_step[4] = {0, 1, 4, 8};

#ifdef USE_NEON_ZMAKO_H
static const u8 zmako_h_perm_tables[16][16] = {
	{255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{8, 9, 10, 11, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 8, 9, 10, 11, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 8, 9, 10, 11, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 17, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
};

static const u8 zmako_h_unperm_tables[16][16] = {
	{255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7},
	{0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 255, 255, 255, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 2, 3, 4, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 2, 3, 4, 5, 6, 7, 8},
	{0, 1, 2, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 255, 255, 255, 255, 4, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 255, 255, 255, 255, 4, 5, 6, 7, 255, 255, 255, 255},
	{0, 1, 2, 3, 255, 255, 255, 255, 4, 5, 6, 7, 8, 9, 10, 11},
	{0, 1, 2, 3, 4, 5, 6, 7, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
};

static const u8 zmako_h_length_tables[16] = {
	0, 1, 4, 8, 1, 2, 5, 9, 4, 5, 8, 12, 8, 9, 12, 16
};
#endif

static void zmako_h_release_params(struct zcomp_params *params) {}
static int zmako_h_setup_params(struct zcomp_params *params) { return 0; }
static void zmako_h_destroy(struct zcomp_ctx *ctx) {}

static int zmako_h_create(struct zcomp_params *params, struct zcomp_ctx *ctx)
{
	ctx->context = NULL;
	return 0;
}

static int zmako_h_compress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			  struct zcomp_req *req)
{
	const u64 *src_words = (const u64 *)req->src;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	u64 *tags_out = (u64 *)req->dst;
	u8 *payload_base = req->dst + tag_area_size;

	u32 payload_offset = 0;
	u64 current_tags = 0;
	int tag_shift = 0;
	u64 dict[257] = {0};
	int i = 0;

#ifdef USE_NEON_ZMAKO_H
	kernel_neon_begin();
	for (; i <= words_per_page - 4; i += 4) {
		prefetch(src_words + i + 8);

		u64 word0 = src_words[i];
		u64 word1 = src_words[i+1];

		u8 h0 = (word0 * HASH_MULTIPLIER) >> HASH_SHIFT;
		u64 d_word0 = dict[h0];
		bool is_zero0  = (word0 == 0);
		bool is_exact0 = (d_word0 == word0);
		bool is_small0 = ((word0 >> 32) == 0);
		u8 s0 = is_zero0 ? 0 : (is_exact0 ? 1 : (is_small0 ? 2 : 3));
		int mask0 = -(s0 >> 1);
		u16 idx0 = (h0 & mask0) | (256 & ~mask0);
		dict[idx0] = word0;

		u8 h1 = (word1 * HASH_MULTIPLIER) >> HASH_SHIFT;
		u64 d_word1 = dict[h1];
		bool is_zero1  = (word1 == 0);
		bool is_exact1 = (d_word1 == word1);
		bool is_small1 = ((word1 >> 32) == 0);
		u8 s1 = is_zero1 ? 0 : (is_exact1 ? 1 : (is_small1 ? 2 : 3));
		int mask1 = -(s1 >> 1);
		u16 idx1 = (h1 & mask1) | (256 & ~mask1);
		dict[idx1] = word1;

		u8 cs0 = (s0 << 2) | s1;
		uint8x16_t perm0 = vld1q_u8(zmako_h_perm_tables[cs0]);
		
		uint64x2_t words_64_0 = vsetq_lane_u64(word0, vdupq_n_u64(0), 0);
		words_64_0 = vsetq_lane_u64(word1, words_64_0, 1);
		uint8x16_t words_reg0 = vreinterpretq_u8_u64(words_64_0);

		uint16_t hashes0 = h0 | ((uint16_t)h1 << 8);
		uint8x16_t hash_reg0 = vreinterpretq_u8_u16(vdupq_n_u16(hashes0));

		uint8x16x2_t table0 = { words_reg0, hash_reg0 };
		uint8x16_t packed0 = vqtbl2q_u8(table0, perm0);

		vst1q_u8(payload_base + payload_offset, packed0);
		payload_offset += zmako_h_length_tables[cs0];

		current_tags |= ((u64)s0 << tag_shift);
		current_tags |= ((u64)s1 << (tag_shift + 2));
		tag_shift += 4;

		u64 word2 = src_words[i+2];
		u64 word3 = src_words[i+3];

		u8 h2 = (word2 * HASH_MULTIPLIER) >> HASH_SHIFT;
		u64 d_word2 = dict[h2];
		bool is_zero2  = (word2 == 0);
		bool is_exact2 = (d_word2 == word2);
		bool is_small2 = ((word2 >> 32) == 0);
		u8 s2 = is_zero2 ? 0 : (is_exact2 ? 1 : (is_small2 ? 2 : 3));
		int mask2 = -(s2 >> 1);
		u16 idx2 = (h2 & mask2) | (256 & ~mask2);
		dict[idx2] = word2;

		u8 h3 = (word3 * HASH_MULTIPLIER) >> HASH_SHIFT;
		u64 d_word3 = dict[h3];
		bool is_zero3  = (word3 == 0);
		bool is_exact3 = (d_word3 == word3);
		bool is_small3 = ((word3 >> 32) == 0);
		u8 s3 = is_zero3 ? 0 : (is_exact3 ? 1 : (is_small3 ? 2 : 3));
		int mask3 = -(s3 >> 1);
		u16 idx3 = (h3 & mask3) | (256 & ~mask3);
		dict[idx3] = word3;

		u8 cs1 = (s2 << 2) | s3;
		uint8x16_t perm1 = vld1q_u8(zmako_h_perm_tables[cs1]);
		
		uint64x2_t words_64_1 = vsetq_lane_u64(word2, vdupq_n_u64(0), 0);
		words_64_1 = vsetq_lane_u64(word3, words_64_1, 1);
		uint8x16_t words_reg1 = vreinterpretq_u8_u64(words_64_1);

		uint16_t hashes1 = h2 | ((uint16_t)h3 << 8);
		uint8x16_t hash_reg1 = vreinterpretq_u8_u16(vdupq_n_u16(hashes1));

		uint8x16x2_t table1 = { words_reg1, hash_reg1 };
		uint8x16_t packed1 = vqtbl2q_u8(table1, perm1);

		vst1q_u8(payload_base + payload_offset, packed1);
		payload_offset += zmako_h_length_tables[cs1];

		current_tags |= ((u64)s2 << tag_shift);
		current_tags |= ((u64)s3 << (tag_shift + 2));
		tag_shift += 4;

		if (unlikely(tag_shift >= 64)) {
			*tags_out++ = current_tags;
			current_tags = 0;
			tag_shift = 0;
		}
	}
	kernel_neon_end();
#endif

	for (; i < words_per_page; i++) {
		u64 word = src_words[i];
		u8 hash = (word * HASH_MULTIPLIER) >> HASH_SHIFT;
		u64 d_word = dict[hash];

		bool is_zero  = (word == 0);
		bool is_exact = (d_word == word);
		bool is_small = ((word >> 32) == 0);

		u8 state = is_zero ? 0 : (is_exact ? 1 : (is_small ? 2 : 3));

		u64 out_val = (state == 3) ? word :
			      (state == 2) ? (u32)word :
			      (state == 1) ? hash : 0;

		put_unaligned(out_val, (u64 *)(payload_base + payload_offset));
		payload_offset += payload_step[state];

		int mask = -(state >> 1);
		u16 update_idx = (hash & mask) | (256 & ~mask);
		dict[update_idx] = word;

		current_tags |= ((u64)state << tag_shift);
		tag_shift += 2;

		if (unlikely(tag_shift >= 64)) {
			*tags_out++ = current_tags;
			current_tags = 0;
			tag_shift = 0;
		}
	}

	put_unaligned(0ULL, (u64 *)(payload_base + payload_offset));
	put_unaligned(0ULL, (u64 *)(payload_base + payload_offset + 8));
	
	req->dst_len = tag_area_size + payload_offset + 16;
	return 0;
}

static int zmako_h_decompress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			    struct zcomp_req *req)
{
	u64 *dst_words = (u64 *)req->dst;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	const u64 *tags_in = (const u64 *)req->src;
	const u8 *payload = req->src + tag_area_size;

	u64 current_tags = 0;
	int tag_shift = 64;
	u64 dict[257] = {0};
	int i = 0;

#ifdef USE_NEON_ZMAKO_H
	kernel_neon_begin();
	for (; i <= words_per_page - 4; i += 4) {
		prefetch(payload + 32);
		prefetchw(dst_words + i + 8);

		if (unlikely(tag_shift >= 64)) {
			current_tags = *tags_in++;
			tag_shift = 0;
		}

		u8 s0 = (current_tags >> tag_shift) & 0x03;
		u8 s1 = (current_tags >> (tag_shift + 2)) & 0x03;
		tag_shift += 4;
		u8 cs0 = (s0 << 2) | s1;

		uint8x16_t packed0 = vld1q_u8(payload);
		uint8x16_t unpacked0 = vqtbl1q_u8(packed0, vld1q_u8(zmako_h_unperm_tables[cs0]));
		payload += zmako_h_length_tables[cs0];

		uint64x2_t unpacked_64_0 = vreinterpretq_u64_u8(unpacked0);
		u64 w0_raw = vgetq_lane_u64(unpacked_64_0, 0);
		u64 w1_raw = vgetq_lane_u64(unpacked_64_0, 1);

		u8 hash0 = w0_raw & DICT_MASK;
		u64 d_val0 = dict[hash0];
		u64 out0 = (s0 == 3) ? w0_raw :
			       (s0 == 2) ? (u32)w0_raw :
			       (s0 == 1) ? d_val0 : 0;
		dst_words[i] = out0;
		u8 hash_new0 = (out0 * HASH_MULTIPLIER) >> HASH_SHIFT;
		u16 eff_hash0 = (s0 == 3) ? hash_new0 : hash0;
		int mask0 = -(s0 >> 1);
		u16 idx0 = (eff_hash0 & mask0) | (256 & ~mask0);
		dict[idx0] = out0;

		u8 hash1 = w1_raw & DICT_MASK;
		u64 d_val1 = dict[hash1];
		u64 out1 = (s1 == 3) ? w1_raw :
			       (s1 == 2) ? (u32)w1_raw :
			       (s1 == 1) ? d_val1 : 0;
		dst_words[i+1] = out1;
		u8 hash_new1 = (out1 * HASH_MULTIPLIER) >> HASH_SHIFT;
		u16 eff_hash1 = (s1 == 3) ? hash_new1 : hash1;
		int mask1 = -(s1 >> 1);
		u16 idx1 = (eff_hash1 & mask1) | (256 & ~mask1);
		dict[idx1] = out1;

		u8 s2 = (current_tags >> tag_shift) & 0x03;
		u8 s3 = (current_tags >> (tag_shift + 2)) & 0x03;
		tag_shift += 4;
		u8 cs1 = (s2 << 2) | s3;

		uint8x16_t packed1 = vld1q_u8(payload);
		uint8x16_t unpacked1 = vqtbl1q_u8(packed1, vld1q_u8(zmako_h_unperm_tables[cs1]));
		payload += zmako_h_length_tables[cs1];

		uint64x2_t unpacked_64_1 = vreinterpretq_u64_u8(unpacked1);
		u64 w2_raw = vgetq_lane_u64(unpacked_64_1, 0);
		u64 w3_raw = vgetq_lane_u64(unpacked_64_1, 1);

		u8 hash2 = w2_raw & DICT_MASK;
		u64 d_val2 = dict[hash2];
		u64 out2 = (s2 == 3) ? w2_raw :
			       (s2 == 2) ? (u32)w2_raw :
			       (s2 == 1) ? d_val2 : 0;
		dst_words[i+2] = out2;
		u8 hash_new2 = (out2 * HASH_MULTIPLIER) >> HASH_SHIFT;
		u16 eff_hash2 = (s2 == 3) ? hash_new2 : hash2;
		int mask2 = -(s2 >> 1);
		u16 idx2 = (eff_hash2 & mask2) | (256 & ~mask2);
		dict[idx2] = out2;

		u8 hash3 = w3_raw & DICT_MASK;
		u64 d_val3 = dict[hash3];
		u64 out3 = (s3 == 3) ? w3_raw :
			       (s3 == 2) ? (u32)w3_raw :
			       (s3 == 1) ? d_val3 : 0;
		dst_words[i+3] = out3;
		u8 hash_new3 = (out3 * HASH_MULTIPLIER) >> HASH_SHIFT;
		u16 eff_hash3 = (s3 == 3) ? hash_new3 : hash3;
		int mask3 = -(s3 >> 1);
		u16 idx3 = (eff_hash3 & mask3) | (256 & ~mask3);
		dict[idx3] = out3;
	}
	kernel_neon_end();
#endif

	for (; i < words_per_page; i++) {
		if (unlikely(tag_shift >= 64)) {
			current_tags = *tags_in++;
			tag_shift = 0;
		}

		u8 state = (current_tags >> tag_shift) & 0x03;
		tag_shift += 2;

		u64 p_val = get_unaligned((const u64 *)payload);
		u8 hash = p_val & DICT_MASK;
		u64 d_val = dict[hash];

		u64 out_word = (state == 3) ? p_val :
			       (state == 2) ? (u32)p_val :
			       (state == 1) ? d_val : 0;

		dst_words[i] = out_word;

		u8 hash3 = (out_word * HASH_MULTIPLIER) >> HASH_SHIFT;
		u16 eff_hash = (state == 3) ? hash3 : hash;
		int mask = -(state >> 1);
		u16 update_idx = (eff_hash & mask) | (256 & ~mask);
		dict[update_idx] = out_word;

		payload += payload_step[state];
	}

	return 0;
}

const struct zcomp_ops backend_zmako_h = {
	.compress	= zmako_h_compress,
	.decompress	= zmako_h_decompress,
	.create_ctx	= zmako_h_create,
	.destroy_ctx	= zmako_h_destroy,
	.setup_params	= zmako_h_setup_params,
	.release_params	= zmako_h_release_params,
	.name		= "zmako_h",
};
