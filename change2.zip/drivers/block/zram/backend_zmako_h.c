#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <asm/unaligned.h>
#include <linux/types.h>

#if defined(CONFIG_ARM64) || defined(__aarch64__)
#define USE_NEON_ZMAKO_H 1

#include <asm/neon.h>

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wbuiltin-macro-redefined"

#undef __INT64_TYPE__
#define __INT64_TYPE__ long long
#undef __UINT64_TYPE__
#define __UINT64_TYPE__ unsigned long long

#undef __SIZE_MAX__
#define __SIZE_MAX__ (~(size_t)0)
#undef __UINTPTR_MAX__
#define __UINTPTR_MAX__ ULONG_MAX

#include <arm_neon.h>

#pragma GCC diagnostic pop

#endif

#include "backend_zmako_h.h"

#define DICT_SIZE 256
#define DICT_MASK 0xFF
#define HASH_MULTIPLIER 0x9E3779B185EBCA87ULL
#define HASH_SHIFT 56

static const u8 payload_step[4] = {0, 1, 4, 8};

#ifdef USE_NEON_ZMAKO_H
static const u8 zmako_h_perm_tables[16][16] = {
	{255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{8, 9, 10, 11, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 8, 9, 10, 11, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 8, 9, 10, 11, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 17, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
};

static const u8 zmako_h_unperm_tables[16][16] = {
	{255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7},
	{0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 255, 255, 255, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 2, 3, 4, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 2, 3, 4, 5, 6, 7, 8},
	{0, 1, 2, 3, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 255, 255, 255, 255, 4, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 255, 255, 255, 255, 4, 5, 6, 7, 255, 255, 255, 255},
	{0, 1, 2, 3, 255, 255, 255, 255, 4, 5, 6, 7, 8, 9, 10, 11},
	{0, 1, 2, 3, 4, 5, 6, 7, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
};

static const u8 zmako_h_length_tables[16] = {
	0, 1, 4, 8, 1, 2, 5, 9, 4, 5, 8, 12, 8, 9, 12, 16
};
#endif

static void zmako_h_release_params(struct zcomp_params *params) {}
static int zmako_h_setup_params(struct zcomp_params *params) { return 0; }
static void zmako_h_destroy(struct zcomp_ctx *ctx) {}

static int zmako_h_create(struct zcomp_params *params, struct zcomp_ctx *ctx)
{
	ctx->context = NULL;
	return 0;
}

static int zmako_h_compress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			  struct zcomp_req *req)
{
	const u64 *src_words = (const u64 *)req->src;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	u64 *tags_out = (u64 *)req->dst;
	u8 *payload_base = req->dst + tag_area_size;

	u32 payload_offset = 0;
	u64 current_tags = 0;
	int tag_shift = 0;
	u64 dict[257] = {0};
	int i = 0;

#ifdef USE_NEON_ZMAKO_H
	kernel_neon_begin();
	for (; i <= words_per_page - 4; i += 4) {
		__builtin_prefetch(&src_words[i + 8], 0, 1);

		uint64x2_t w64_0 = vld1q_u64((const unsigned long *)&src_words[i]);
		uint64x2_t w64_1 = vld1q_u64((const unsigned long *)&src_words[i + 2]);

		u64 w0 = vgetq_lane_u64(w64_0, 0);
		u64 w1 = vgetq_lane_u64(w64_0, 1);
		u64 w2 = vgetq_lane_u64(w64_1, 0);
		u64 w3 = vgetq_lane_u64(w64_1, 1);

		u8 h0 = (w0 * HASH_MULTIPLIER) >> HASH_SHIFT;
		u8 h1 = (w1 * HASH_MULTIPLIER) >> HASH_SHIFT;
		u8 h2 = (w2 * HASH_MULTIPLIER) >> HASH_SHIFT;
		u8 h3 = (w3 * HASH_MULTIPLIER) >> HASH_SHIFT;

		bool z0 = (w0 == 0); bool e0 = (dict[h0] == w0); bool m0 = ((w0 >> 32) == 0);
		bool z1 = (w1 == 0); bool e1 = (dict[h1] == w1); bool m1 = ((w1 >> 32) == 0);
		bool z2 = (w2 == 0); bool e2 = (dict[h2] == w2); bool m2 = ((w2 >> 32) == 0);
		bool z3 = (w3 == 0); bool e3 = (dict[h3] == w3); bool m3 = ((w3 >> 32) == 0);

		u8 s0 = z0 ? 0 : (e0 ? 1 : (m0 ? 2 : 3));
		u8 s1 = z1 ? 0 : (e1 ? 1 : (m1 ? 2 : 3));
		u8 s2 = z2 ? 0 : (e2 ? 1 : (m2 ? 2 : 3));
		u8 s3 = z3 ? 0 : (e3 ? 1 : (m3 ? 2 : 3));

		dict[h0 | (z0 << 8)] = w0;
		dict[h1 | (z1 << 8)] = w1;
		dict[h2 | (z2 << 8)] = w2;
		dict[h3 | (z3 << 8)] = w3;

		u8 cs0 = (s0 << 2) | s1;
		u8 cs1 = (s2 << 2) | s3;

		uint8x16_t w_reg0 = vreinterpretq_u8_u64(w64_0);
		uint8x16_t h_reg0 = vreinterpretq_u8_u16(vdupq_n_u16(h0 | ((u16)h1 << 8)));
		uint8x16x2_t tab0 = { w_reg0, h_reg0 };
		vst1q_u8(payload_base + payload_offset, vqtbl2q_u8(tab0, vld1q_u8(zmako_h_perm_tables[cs0])));
		payload_offset += zmako_h_length_tables[cs0];

		uint8x16_t w_reg1 = vreinterpretq_u8_u64(w64_1);
		uint8x16_t h_reg1 = vreinterpretq_u8_u16(vdupq_n_u16(h2 | ((u16)h3 << 8)));
		uint8x16x2_t tab1 = { w_reg1, h_reg1 };
		vst1q_u8(payload_base + payload_offset, vqtbl2q_u8(tab1, vld1q_u8(zmako_h_perm_tables[cs1])));
		payload_offset += zmako_h_length_tables[cs1];

		current_tags |= ((u64)s0 << tag_shift);
		current_tags |= ((u64)s1 << (tag_shift + 2));
		current_tags |= ((u64)s2 << (tag_shift + 4));
		current_tags |= ((u64)s3 << (tag_shift + 6));
		tag_shift += 8;

		if (unlikely(tag_shift == 64)) {
			*tags_out++ = current_tags;
			current_tags = 0;
			tag_shift = 0;
		}
	}
	kernel_neon_end();
#endif
	for (; i < words_per_page; i++) {
		u64 word = src_words[i];
		u8 hash = (word * HASH_MULTIPLIER) >> HASH_SHIFT;

		bool is_zero  = (word == 0);
		bool is_exact = (dict[hash] == word);
		bool is_small = ((word >> 32) == 0);

		u8 state = is_zero ? 0 : (is_exact ? 1 : (is_small ? 2 : 3));
		u64 out_val = (state == 3) ? word : ((state == 2) ? (u32)word : ((state == 1) ? hash : 0));

		put_unaligned(out_val, (u64 *)(payload_base + payload_offset));
		payload_offset += payload_step[state];

		dict[hash | (is_zero << 8)] = word;

		current_tags |= ((u64)state << tag_shift);
		tag_shift += 2;

		if (unlikely(tag_shift == 64)) {
			*tags_out++ = current_tags;
			current_tags = 0;
			tag_shift = 0;
		}
	}

	put_unaligned(0ULL, (u64 *)(payload_base + payload_offset));
	put_unaligned(0ULL, (u64 *)(payload_base + payload_offset + 8));
	
	req->dst_len = tag_area_size + payload_offset + 16;
	return 0;
}

static int zmako_h_decompress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			    struct zcomp_req *req)
{
	u64 *dst_words = (u64 *)req->dst;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	const u64 *tags_in = (const u64 *)req->src;
	const u8 *payload = req->src + tag_area_size;

	u64 current_tags = 0;
	int tag_shift = 64;
	u64 dict[257] = {0};
	int i = 0;

#ifdef USE_NEON_ZMAKO_H
	kernel_neon_begin();
	for (; i <= words_per_page - 4; i += 4) {
		__builtin_prefetch(&dst_words[i + 8], 1, 1);
		__builtin_prefetch(payload + 32, 0, 1);

		if (unlikely(tag_shift >= 64)) {
			current_tags = *tags_in++;
			tag_shift = 0;
		}

		u8 s0 = (current_tags >> tag_shift) & 0x03;
		u8 s1 = (current_tags >> (tag_shift + 2)) & 0x03;
		u8 s2 = (current_tags >> (tag_shift + 4)) & 0x03;
		u8 s3 = (current_tags >> (tag_shift + 6)) & 0x03;
		tag_shift += 8;

		u8 cs0 = (s0 << 2) | s1;
		u8 cs1 = (s2 << 2) | s3;

		uint8x16_t unpacked0 = vqtbl1q_u8(vld1q_u8(payload), vld1q_u8(zmako_h_unperm_tables[cs0]));
		payload += zmako_h_length_tables[cs0];

		uint8x16_t unpacked1 = vqtbl1q_u8(vld1q_u8(payload), vld1q_u8(zmako_h_unperm_tables[cs1]));
		payload += zmako_h_length_tables[cs1];

		uint64x2_t unp64_0 = vreinterpretq_u64_u8(unpacked0);
		uint64x2_t unp64_1 = vreinterpretq_u64_u8(unpacked1);

		u64 w0_raw = vgetq_lane_u64(unp64_0, 0);
		u64 w1_raw = vgetq_lane_u64(unp64_0, 1);
		u64 w2_raw = vgetq_lane_u64(unp64_1, 0);
		u64 w3_raw = vgetq_lane_u64(unp64_1, 1);

		u64 out0 = (s0 == 3) ? w0_raw : ((s0 == 2) ? (u32)w0_raw : ((s0 == 1) ? dict[w0_raw & DICT_MASK] : 0));
		dst_words[i] = out0;
		dict[((out0 * HASH_MULTIPLIER) >> HASH_SHIFT) | ((out0 == 0) << 8)] = out0;

		u64 out1 = (s1 == 3) ? w1_raw : ((s1 == 2) ? (u32)w1_raw : ((s1 == 1) ? dict[w1_raw & DICT_MASK] : 0));
		dst_words[i+1] = out1;
		dict[((out1 * HASH_MULTIPLIER) >> HASH_SHIFT) | ((out1 == 0) << 8)] = out1;

		u64 out2 = (s2 == 3) ? w2_raw : ((s2 == 2) ? (u32)w2_raw : ((s2 == 1) ? dict[w2_raw & DICT_MASK] : 0));
		dst_words[i+2] = out2;
		dict[((out2 * HASH_MULTIPLIER) >> HASH_SHIFT) | ((out2 == 0) << 8)] = out2;

		u64 out3 = (s3 == 3) ? w3_raw : ((s3 == 2) ? (u32)w3_raw : ((s3 == 1) ? dict[w3_raw & DICT_MASK] : 0));
		dst_words[i+3] = out3;
		dict[((out3 * HASH_MULTIPLIER) >> HASH_SHIFT) | ((out3 == 0) << 8)] = out3;
	}
	kernel_neon_end();
#endif

	for (; i < words_per_page; i++) {
		if (unlikely(tag_shift >= 64)) {
			current_tags = *tags_in++;
			tag_shift = 0;
		}

		u8 state = (current_tags >> tag_shift) & 0x03;
		tag_shift += 2;

		u64 p_val = get_unaligned((const u64 *)payload);
		u64 out_word = (state == 3) ? p_val : ((state == 2) ? (u32)p_val : ((state == 1) ? dict[p_val & DICT_MASK] : 0));
		dst_words[i] = out_word;

		dict[((out_word * HASH_MULTIPLIER) >> HASH_SHIFT) | ((out_word == 0) << 8)] = out_word;
		payload += payload_step[state];
	}

	return 0;
}

const struct zcomp_ops backend_zmako_h = {
	.compress	= zmako_h_compress,
	.decompress	= zmako_h_decompress,
	.create_ctx	= zmako_h_create,
	.destroy_ctx	= zmako_h_destroy,
	.setup_params	= zmako_h_setup_params,
	.release_params	= zmako_h_release_params,
	.name		= "zmako_h",
};
