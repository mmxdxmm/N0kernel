#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/string.h>

#include "backend_zmako_h.h"

#define DICT_SIZE 256
#define DICT_MASK 0xFF
#define HASH_MULTIPLIER 0x9E3779B185EBCA87ULL

static const u8 payload_step[4] = {0, 1, 3, 8};

struct zmako_h_ctx {
	u64 dict[DICT_SIZE];
};

static void zmako_h_release_params(struct zcomp_params *params) {}
static int zmako_h_setup_params(struct zcomp_params *params) { return 0; }

static void zmako_h_destroy(struct zcomp_ctx *ctx)
{
	kfree(ctx->context);
	ctx->context = NULL;
}

static int zmako_h_create(struct zcomp_params *params, struct zcomp_ctx *ctx)
{
	struct zmako_h_ctx *zctx;
	
	zctx = kzalloc(sizeof(*zctx), GFP_KERNEL);
	if (!zctx)
		return -ENOMEM;
		
	ctx->context = zctx;
	return 0;
}

static int zmako_h_compress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			  struct zcomp_req *req)
{
	const u64 *src_words = (const u64 *)req->src;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;
	
	u64 *tags_out = (u64 *)req->dst;
	u8 *payload_base = req->dst + tag_area_size;
	
	u32 max_payload_offset = PAGE_SIZE - tag_area_size - 8;
	u32 payload_offset = 0;
	
	struct zmako_h_ctx *zctx = ctx->context;
	u64 *dict = zctx->dict;
	memset(dict, 0, sizeof(u64) * DICT_SIZE);
	
	u64 current_tags = 0;
	int tag_shift = 0;
	int i = 0;

	u8 state;
	u8 hash;
	u64 word;

	while (i < words_per_page && payload_offset <= max_payload_offset) {
		word = src_words[i++];
		state = 0;
		hash = 0;

		if (word != 0) {
			hash = (word * HASH_MULTIPLIER) >> 56;
			if (dict[hash] == word) {
				state = 1;
				payload_base[payload_offset] = hash;
			} else if ((word >> 16) == (dict[hash] >> 16)) {
				state = 2;
				payload_base[payload_offset] = hash;
				payload_base[payload_offset + 1] = (u8)(word & 0xFF);
				payload_base[payload_offset + 2] = (u8)((word >> 8) & 0xFF);
				dict[hash] = word;
			} else {
				state = 3;
				memcpy(payload_base + payload_offset, &word, 8);
				dict[hash] = word;
			}
		}

		payload_offset += payload_step[state];
		current_tags |= ((u64)state << tag_shift);
		tag_shift += 2;
		
		if (unlikely(tag_shift == 64)) {
			*tags_out++ = current_tags;
			current_tags = 0;
			tag_shift = 0;
		}
	}

	while (i < words_per_page) {
		word = src_words[i++];
		state = 0;

		if (word != 0) {
			hash = (word * HASH_MULTIPLIER) >> 56;
			if (dict[hash] == word) {
				state = 1;
			} else if ((word >> 16) == (dict[hash] >> 16)) {
				state = 2;
				dict[hash] = word;
			} else {
				state = 3;
				dict[hash] = word;
			}
		}

		payload_offset += payload_step[state];
		current_tags |= ((u64)state << tag_shift);
		tag_shift += 2;
		
		if (unlikely(tag_shift == 64)) {
			*tags_out++ = current_tags;
			current_tags = 0;
			tag_shift = 0;
		}
	}

	req->dst_len = tag_area_size + payload_offset;
	return 0;
}

static int zmako_h_decompress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			    struct zcomp_req *req)
{
	u64 *dst_words = (u64 *)req->dst;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;
	
	const u64 *tags_in = (const u64 *)req->src;
	const u8 *payload = req->src + tag_area_size;
	const u8 *payload_limit = req->src + req->src_len;
	const u8 *payload_safe_limit = payload_limit - 8;
	
	struct zmako_h_ctx *zctx = ctx->context;
	u64 *dict = zctx->dict;
	memset(dict, 0, sizeof(u64) * DICT_SIZE);
	
	u64 current_tags = 0;
	int tag_shift = 64;
	int i = 0;

	u8 state;
	u8 hash;
	u16 delta;
	u64 word;

	while (i < words_per_page && payload <= payload_safe_limit) {
		if (unlikely(tag_shift == 64)) {
			current_tags = *tags_in++;
			tag_shift = 0;
		}
		
		state = (current_tags >> tag_shift) & 0x03;
		tag_shift += 2;

		word = 0;

		switch (state) {
			case 0:
				word = 0;
				break;
			case 1:
				hash = payload[0];
				word = dict[hash];
				break;
			case 2:
				hash = payload[0];
				delta = (u16)payload[1] | ((u16)payload[2] << 8);
				word = (dict[hash] & 0xFFFFFFFFFFFF0000ULL) | delta;
				dict[hash] = word;
				break;
			case 3:
				memcpy(&word, payload, 8);
				hash = (word * HASH_MULTIPLIER) >> 56;
				dict[hash] = word;
				break;
		}

		dst_words[i++] = word;
		payload += payload_step[state]; 
	}

	while (i < words_per_page) {
		if (unlikely(tag_shift == 64)) {
			current_tags = *tags_in++;
			tag_shift = 0;
		}
		
		state = (current_tags >> tag_shift) & 0x03;
		tag_shift += 2;

		if (state == 0) {
			dst_words[i++] = 0;
		} else if (state == 1) {
			if (unlikely(payload >= payload_limit)) return -EINVAL;
			hash = *payload++;
			dst_words[i++] = dict[hash];
		} else if (state == 2) {
			if (unlikely(payload + 2 >= payload_limit)) return -EINVAL;
			hash = *payload++;
			delta = (u16)payload[0] | ((u16)payload[1] << 8);
			payload += 2;
			word = (dict[hash] & 0xFFFFFFFFFFFF0000ULL) | delta;
			dst_words[i++] = word;
			dict[hash] = word;
		} else {
			if (unlikely(payload + 7 >= payload_limit)) return -EINVAL;
			memcpy(&word, payload, 8);
			payload += 8;
			dst_words[i++] = word;
			dict[(word * HASH_MULTIPLIER) >> 56] = word;
		}
	}
	
	return 0;
}

const struct zcomp_ops backend_zmako_h = {
	.compress	= zmako_h_compress,
	.decompress	= zmako_h_decompress,
	.create_ctx	= zmako_h_create,
	.destroy_ctx	= zmako_h_destroy,
	.setup_params	= zmako_h_setup_params,
	.release_params	= zmako_h_release_params,
	.name		= "zmako_h",
};
