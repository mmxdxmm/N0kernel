// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef __BACKEND_ZMAKO_H__
#define __BACKEND_ZMAKO_H__

#include "zcomp.h"
extern const struct zcomp_ops backend_zmako;

#endif /* __BACKEND_ZMAKO_H__ */
