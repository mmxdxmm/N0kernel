// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef __BACKEND_ZMAKO_H_H__
#define __BACKEND_ZMAKO_H_H__

#include "zcomp.h"
extern const struct zcomp_ops backend_zmako_h;

#endif /* __BACKEND_ZMAKO_H_H__ */
