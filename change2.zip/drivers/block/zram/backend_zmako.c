#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <asm/unaligned.h>

#include "backend_zmako.h"

#define DICT_SIZE 64
#define DICT_MASK 0x3F
#define HASH_MULTIPLIER 0x9E3779B185EBCA87ULL

static const u8 payload_step[4] = {0, 1, 2, 8};

static void zmako_release_params(struct zcomp_params *params) {}
static int zmako_setup_params(struct zcomp_params *params) { return 0; }
static void zmako_destroy(struct zcomp_ctx *ctx) {}

static int zmako_create(struct zcomp_params *params, struct zcomp_ctx *ctx)
{
	ctx->context = NULL;
	return 0;
}

static int zmako_compress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			  struct zcomp_req *req)
{
	const u64 *src_words = (const u64 *)req->src;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	u64 *tags_out = (u64 *)req->dst;
	u8 *payload_base = req->dst + tag_area_size;

	u32 payload_offset = 0;
	u64 current_tags = 0;
	int tag_shift = 0;

	u64 dict[65] = {0};

	for (int i = 0; i < words_per_page; i++) {
		u64 word = src_words[i];
		u8 hash = (word * HASH_MULTIPLIER) >> 58;
		u64 d_word = dict[hash];

		bool is_zero  = (word == 0);
		bool is_exact = (d_word == word);
		bool is_base  = ((word >> 8) == (d_word >> 8));

		u8 state = is_zero ? 0 : (is_exact ? 1 : (is_base ? 2 : 3));

		u64 out_val = (state == 3) ? word :
			      (state == 2) ? (hash | ((word & 0xFF) << 8)) :
			      (state == 1) ? hash : 0;

		put_unaligned(out_val, (u64 *)(payload_base + payload_offset));
		payload_offset += payload_step[state];

		u8 update_idx = (state == 0) ? 64 : hash;
		dict[update_idx] = word;

		current_tags |= ((u64)state << tag_shift);
		tag_shift += 2;

		if (unlikely(tag_shift == 64)) {
			*tags_out++ = current_tags;
			current_tags = 0;
			tag_shift = 0;
		}
	}

	req->dst_len = tag_area_size + payload_offset;
	return 0;
}

static int zmako_decompress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			    struct zcomp_req *req)
{
	u64 *dst_words = (u64 *)req->dst;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	const u64 *tags_in = (const u64 *)req->src;
	const u8 *payload = req->src + tag_area_size;

	u64 current_tags = 0;
	int tag_shift = 64;

	u64 dict[65] = {0};

	for (int i = 0; i < words_per_page; i++) {
		if (unlikely(tag_shift == 64)) {
			current_tags = *tags_in++;
			tag_shift = 0;
		}

		u8 state = (current_tags >> tag_shift) & 0x03;
		tag_shift += 2;

		u64 p_val = get_unaligned((const u64 *)payload);
		u8 hash = p_val & DICT_MASK;
		u8 delta = (p_val >> 8) & 0xFF;

		u64 d_val = dict[hash];

		u64 res2 = (d_val & 0xFFFFFFFFFFFFFF00ULL) | delta;

		u64 out_word = (state == 3) ? p_val :
			       (state == 2) ? res2 :
			       (state == 1) ? d_val : 0;

		dst_words[i] = out_word;

		u8 hash3 = (out_word * HASH_MULTIPLIER) >> 58;
		u8 update_idx = (state == 3) ? hash3 :
				(state == 0) ? 64 : hash;

		dict[update_idx] = out_word;

		payload += payload_step[state];
	}

	return 0;
}

const struct zcomp_ops backend_zmako = {
	.compress	= zmako_compress,
	.decompress	= zmako_decompress,
	.create_ctx	= zmako_create,
	.destroy_ctx	= zmako_destroy,
	.setup_params	= zmako_setup_params,
	.release_params	= zmako_release_params,
	.name		= "zmako",
};