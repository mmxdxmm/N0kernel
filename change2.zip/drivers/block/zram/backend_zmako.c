#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/string.h>

#include "backend_zmako.h"

#define DICT_SIZE 64
#define DICT_MASK 0x3F
#define HASH_MULTIPLIER 0x9E3779B185EBCA87ULL

static void zmako_release_params(struct zcomp_params *params) {}
static int zmako_setup_params(struct zcomp_params *params) { return 0; }
static void zmako_destroy(struct zcomp_ctx *ctx) {}

static int zmako_create(struct zcomp_params *params, struct zcomp_ctx *ctx)
{
	ctx->context = NULL;
	return 0;
}

static int zmako_compress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			  struct zcomp_req *req)
{
	const u64 *src_words = (const u64 *)req->src;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;
	u64 *tags_out = (u64 *)req->dst;
	u8 *payload = req->dst + tag_area_size;
	u8 *payload_limit = req->dst + PAGE_SIZE;
	
	u64 dict[DICT_SIZE] = {0};
	u64 current_tags = 0;
	int tag_shift = 0;
	int i;

	for (i = 0; i < words_per_page; i++) {
		u64 word = src_words[i];
		u8 state = 0;

		if (unlikely(payload + 8 > payload_limit))
			return -ENOSPC;

		if (word != 0) {
			u32 hash = (word * HASH_MULTIPLIER) >> 58;

			if (dict[hash] == word) {
				state = 1;
				*payload++ = (u8)hash;
			} else if ((word >> 8) == (dict[hash] >> 8)) {
				state = 2;
				*payload++ = (u8)hash;
				*payload++ = (u8)(word & 0xFF);
				dict[hash] = word;
			} else {
				state = 3;
				memcpy(payload, &word, 8);
				payload += 8;
				dict[hash] = word;
			}
		}

		current_tags |= ((u64)state << tag_shift);
		tag_shift += 2;
		
		if (unlikely(tag_shift == 64)) {
			*tags_out++ = current_tags;
			current_tags = 0;
			tag_shift = 0;
		}
	}

	req->dst_len = payload - req->dst;
	return 0;
}

static int zmako_decompress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			    struct zcomp_req *req)
{
	u64 *dst_words = (u64 *)req->dst;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;
	
	const u64 *tags_in = (const u64 *)req->src;
	const u8 *payload = req->src + tag_area_size;
	const u8 *payload_limit = req->src + req->src_len;
	
	u64 dict[DICT_SIZE] = {0};
	u64 current_tags = 0;
	int tag_shift = 64;
	int i;

	for (i = 0; i < words_per_page; i++) {
		if (unlikely(tag_shift == 64)) {
			current_tags = *tags_in++;
			tag_shift = 0;
		}
		
		u8 state = (current_tags >> tag_shift) & 0x03;
		tag_shift += 2;

		if (state == 0) {
			dst_words[i] = 0;
		} else if (state == 1) {
			if (unlikely(payload >= payload_limit)) return -EINVAL;
			u8 hash = (*payload++) & DICT_MASK; 
			dst_words[i] = dict[hash];
		} else if (state == 2) {
			if (unlikely(payload + 1 >= payload_limit)) return -EINVAL;
			u8 hash = (*payload++) & DICT_MASK;
			u8 delta = *payload++;
			u64 word = (dict[hash] & 0xFFFFFFFFFFFFFF00ULL) | delta;
			dst_words[i] = word;
			dict[hash] = word;
		} else {
			if (unlikely(payload + 7 >= payload_limit)) return -EINVAL;
			u64 word;
			u32 hash;
			memcpy(&word, payload, 8);
			payload += 8;
			dst_words[i] = word;
			hash = (word * HASH_MULTIPLIER) >> 58;
			dict[hash] = word;
		}
	}
	return 0;
}

const struct zcomp_ops backend_zmako = {
	.compress	= zmako_compress,
	.decompress	= zmako_decompress,
	.create_ctx	= zmako_create,
	.destroy_ctx	= zmako_destroy,
	.setup_params	= zmako_setup_params,
	.release_params	= zmako_release_params,
	.name		= "zmako",
};
