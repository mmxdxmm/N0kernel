#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <asm/unaligned.h>
#include <linux/types.h>

#if defined(CONFIG_ARM64) || defined(__aarch64__)
#define USE_NEON_ZMAKO 1

#include <asm/neon.h>

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wbuiltin-macro-redefined"

#undef __INT64_TYPE__
#define __INT64_TYPE__ long long
#undef __UINT64_TYPE__
#define __UINT64_TYPE__ unsigned long long

#undef __SIZE_MAX__
#define __SIZE_MAX__ (~(size_t)0)
#undef __UINTPTR_MAX__
#define __UINTPTR_MAX__ ULONG_MAX

#include <arm_neon.h>

#pragma GCC diagnostic pop

#endif

#include "backend_zmako.h"

#define DICT_SIZE 64
#define DICT_MASK 0x3F

#if defined(__ARM_FEATURE_CRC32)
static inline u32 aarch64_crc32cx(u32 crc, u64 data)
{
	u32 res;
	asm ("crc32cx %w0, %w1, %x2"
	     : "=r" (res)
	     : "r" (crc), "r" (data));
	return res;
}
#define HASH_WORD(word) (aarch64_crc32cx(0, (word)) & DICT_MASK)
#else
#define HASH_MULTIPLIER 0x9E3779B185EBCA87ULL
#define HASH_WORD(word) (((word) * HASH_MULTIPLIER) >> 58)
#endif

static const u8 payload_step[4] __aligned(16) = {0, 1, 2, 8};

#ifdef USE_NEON_ZMAKO
static const u8 zmako_perm_tables[16][16] __aligned(256) = {
	{255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{17, 8, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 17, 8, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255},
	{16, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 0, 17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 0, 17, 8, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 0, 8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 17, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 17, 8, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
};

static const u8 zmako_unperm_tables[16][16] __aligned(256) = {
	{255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 255, 255, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7},
	{0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 255, 255, 255, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 2, 255, 255, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 2, 3, 4, 5, 6, 7, 8},
	{0, 1, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 255, 255, 255, 255, 255, 255, 2, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 255, 255, 255, 255, 255, 255, 2, 3, 255, 255, 255, 255, 255, 255},
	{0, 1, 255, 255, 255, 255, 255, 255, 2, 3, 4, 5, 6, 7, 8, 9},
	{0, 1, 2, 3, 4, 5, 6, 7, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
};

static const u8 zmako_length_tables[16] __aligned(16) = {
	0, 1, 2, 8, 1, 2, 3, 9, 2, 3, 4, 10, 8, 9, 10, 16
};
#endif

struct zmako_context {
	u64 dict[64] __aligned(64);
};

static void zmako_release_params(struct zcomp_params *params) {}
static int zmako_setup_params(struct zcomp_params *params) { return 0; }

static void zmako_destroy(struct zcomp_ctx *ctx)
{
	kfree(ctx->context);
	ctx->context = NULL;
}

static int zmako_create(struct zcomp_params *params, struct zcomp_ctx *ctx)
{
	struct zmako_context *zctx;
	zctx = kzalloc(sizeof(*zctx), GFP_KERNEL);
	if (!zctx)
		return -ENOMEM;
	ctx->context = zctx;
	return 0;
}

static int zmako_compress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			  struct zcomp_req *req)
{
	struct zmako_context *zctx = ctx->context;
	const u64 *src_words = (const u64 *)req->src;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	u64 *tags_out = (u64 *)req->dst;
	u8 *payload_base = req->dst + tag_area_size;

	u32 payload_offset = 0;
	u64 current_tags = 0;
	int tag_shift = 0;
	int i = 0;

	memset(zctx->dict, 0, sizeof(zctx->dict));
	u64 *dict = zctx->dict;

#ifdef USE_NEON_ZMAKO
	kernel_neon_begin();
	for (; i <= words_per_page - 4; i += 2) {
		u64 word0 = src_words[i];
		u64 word1 = src_words[i+1];

		u32 is_zero0 = (word0 == 0);
		u8 h0 = HASH_WORD(word0) & -(u8)(!is_zero0);
		u64 d_word0 = dict[h0];

		u32 is_exact0 = (d_word0 == word0);
		u32 is_base0  = ((word0 >> 8) == (d_word0 >> 8));
		u8 s0 = (3 - is_base0 - is_exact0) & -(u8)(!is_zero0);

		dict[h0] = is_zero0 ? dict[h0] : word0;

		u32 is_zero1 = (word1 == 0);
		u8 h1 = HASH_WORD(word1) & -(u8)(!is_zero1);
		u64 d_word1 = dict[h1];

		u32 is_exact1 = (d_word1 == word1);
		u32 is_base1  = ((word1 >> 8) == (d_word1 >> 8));
		u8 s1 = (3 - is_base1 - is_exact1) & -(u8)(!is_zero1);

		dict[h1] = is_zero1 ? dict[h1] : word1;

		u8 cs = (s0 << 2) | s1;

		uint8x16_t perm = vld1q_u8(zmako_perm_tables[cs]);

		uint64x2_t words_64 = vsetq_lane_u64(word0, vdupq_n_u64(0), 0);
		words_64 = vsetq_lane_u64(word1, words_64, 1);
		uint8x16_t words_reg = vreinterpretq_u8_u64(words_64);

		uint16_t hashes = h0 | ((u16)h1 << 8);
		uint8x16_t hash_reg = vreinterpretq_u8_u16(vdupq_n_u16(hashes));

		uint8x16x2_t table = { words_reg, hash_reg };
		uint8x16_t packed = vqtbl2q_u8(table, perm);

		vst1q_u8(payload_base + payload_offset, packed);
		payload_offset += zmako_length_tables[cs];

		current_tags |= ((u64)s0 << tag_shift);
		current_tags |= ((u64)s1 << (tag_shift + 2));
		tag_shift += 4;

		if (unlikely(tag_shift == 64)) {
			*tags_out++ = current_tags;
			current_tags = 0;
			tag_shift = 0;
		}
	}
	kernel_neon_end();
#endif

	for (; i < words_per_page; i++) {
		u64 word = src_words[i];

		u32 is_zero = (word == 0);
		u8 hash = HASH_WORD(word) & -(u8)(!is_zero);
		u64 d_word = dict[hash];

		u32 is_exact = (d_word == word);
		u32 is_base  = ((word >> 8) == (d_word >> 8));

		u8 state = (3 - is_base - is_exact) & -(u8)(!is_zero);

		u64 out_val = (state == 3) ? word :
			      (state == 2) ? (hash | ((word & 0xFF) << 8)) :
			      (state == 1) ? hash : 0;

		put_unaligned(out_val, (u64 *)(payload_base + payload_offset));
		payload_offset += payload_step[state];

		dict[hash] = is_zero ? dict[hash] : word;

		current_tags |= ((u64)state << tag_shift);
		tag_shift += 2;

		if (unlikely(tag_shift == 64)) {
			*tags_out++ = current_tags;
			current_tags = 0;
			tag_shift = 0;
		}
	}

	put_unaligned(0ULL, (u64 *)(payload_base + payload_offset));
	put_unaligned(0ULL, (u64 *)(payload_base + payload_offset + 8));

	req->dst_len = tag_area_size + payload_offset + 16;
	return 0;
}

static int zmako_decompress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			    struct zcomp_req *req)
{
	struct zmako_context *zctx = ctx->context;
	u64 *dst_words = (u64 *)req->dst;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	const u64 *tags_in = (const u64 *)req->src;
	const u8 *payload = req->src + tag_area_size;

	u64 current_tags = 0;
	int tag_shift = 64;
	int i = 0;

	memset(zctx->dict, 0, sizeof(zctx->dict));
	u64 *dict = zctx->dict;

#ifdef USE_NEON_ZMAKO
	kernel_neon_begin();
	for (; i <= words_per_page - 4; i += 2) {
		if (unlikely(tag_shift >= 64)) {
			current_tags = *tags_in++;
			tag_shift = 0;
		}

		u8 s0 = (current_tags >> tag_shift) & 0x03;
		u8 s1 = (current_tags >> (tag_shift + 2)) & 0x03;
		tag_shift += 4;
		u8 cs = (s0 << 2) | s1;

		uint8x16_t packed = vld1q_u8(payload);
		uint8x16_t unpacked = vqtbl1q_u8(packed, vld1q_u8(zmako_unperm_tables[cs]));
		payload += zmako_length_tables[cs];

		uint64x2_t unpacked_64 = vreinterpretq_u64_u8(unpacked);
		u64 w0_raw = vgetq_lane_u64(unpacked_64, 0);
		u64 w1_raw = vgetq_lane_u64(unpacked_64, 1);

		u8 hash0 = w0_raw & DICT_MASK;
		u8 delta0 = (w0_raw >> 8) & 0xFF;
		u64 d_val0 = dict[hash0];
		u64 out0 = (s0 == 3) ? w0_raw :
			       (s0 == 2) ? ((d_val0 & 0xFFFFFFFFFFFFFF00ULL) | delta0) :
			       (s0 == 1) ? d_val0 : 0;
		dst_words[i] = out0;

		u8 update_hash0 = (s0 == 3) ? HASH_WORD(out0) : hash0;
		dict[update_hash0] = (s0 == 0) ? dict[update_hash0] : out0;

		u8 hash1 = w1_raw & DICT_MASK;
		u8 delta1 = (w1_raw >> 8) & 0xFF;
		u64 d_val1 = dict[hash1];
		u64 out1 = (s1 == 3) ? w1_raw :
			       (s1 == 2) ? ((d_val1 & 0xFFFFFFFFFFFFFF00ULL) | delta1) :
			       (s1 == 1) ? d_val1 : 0;
		dst_words[i+1] = out1;

		u8 update_hash1 = (s1 == 3) ? HASH_WORD(out1) : hash1;
		dict[update_hash1] = (s1 == 0) ? dict[update_hash1] : out1;
	}
	kernel_neon_end();
#endif

	for (; i < words_per_page; i++) {
		if (unlikely(tag_shift >= 64)) {
			current_tags = *tags_in++;
			tag_shift = 0;
		}

		u8 state = (current_tags >> tag_shift) & 0x03;
		tag_shift += 2;

		u64 p_val = get_unaligned((const u64 *)payload);
		u8 hash = p_val & DICT_MASK;
		u8 delta = (p_val >> 8) & 0xFF;

		u64 d_val = dict[hash];

		u64 res2 = (d_val & 0xFFFFFFFFFFFFFF00ULL) | delta;

		u64 out_word = (state == 3) ? p_val :
			       (state == 2) ? res2 :
			       (state == 1) ? d_val : 0;

		dst_words[i] = out_word;

		u8 update_idx = (state == 3) ? HASH_WORD(out_word) : hash;
		dict[update_idx] = (state == 0) ? dict[update_idx] : out_word;

		payload += payload_step[state];
	}

	return 0;
}

const struct zcomp_ops backend_zmako = {
	.compress	= zmako_compress,
	.decompress	= zmako_decompress,
	.create_ctx	= zmako_create,
	.destroy_ctx	= zmako_destroy,
	.setup_params	= zmako_setup_params,
	.release_params	= zmako_release_params,
	.name		= "zmako",
};
