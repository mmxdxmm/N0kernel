#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <asm/unaligned.h>
#include <linux/types.h>

#if defined(CONFIG_ARM64) || defined(__aarch64__)
#define USE_NEON_ZMAKO 1

#include <asm/neon.h>

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wbuiltin-macro-redefined"

#undef __INT64_TYPE__
#define __INT64_TYPE__ long long
#undef __UINT64_TYPE__
#define __UINT64_TYPE__ unsigned long long

#undef __SIZE_MAX__
#define __SIZE_MAX__ (~(size_t)0)
#undef __UINTPTR_MAX__
#define __UINTPTR_MAX__ ULONG_MAX

#include <arm_neon.h>

#pragma GCC diagnostic pop

#endif

#include "backend_zmako.h"

#define DICT_SIZE 64
#define DICT_MASK 0x3F
#define HASH_MULTIPLIER 0x9E3779B185EBCA87ULL

static const u8 payload_step[4] = {0, 1, 2, 8};

#ifdef USE_NEON_ZMAKO
static const u8 zmako_perm_tables[16][16] = {
	{255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{17, 8, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 17, 8, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255},
	{16, 0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 0, 17, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 0, 17, 8, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{16, 0, 8, 9, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 17, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 17, 8, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
};

static const u8 zmako_unperm_tables[16][16] = {
	{255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 255, 255, 255, 255, 255, 255},
	{255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7},
	{0, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 255, 255, 255, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 2, 255, 255, 255, 255, 255, 255},
	{0, 255, 255, 255, 255, 255, 255, 255, 1, 2, 3, 4, 5, 6, 7, 8},
	{0, 1, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 255, 255, 255, 255, 255, 255, 2, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 255, 255, 255, 255, 255, 255, 2, 3, 255, 255, 255, 255, 255, 255},
	{0, 1, 255, 255, 255, 255, 255, 255, 2, 3, 4, 5, 6, 7, 8, 9},
	{0, 1, 2, 3, 4, 5, 6, 7, 255, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 255, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255},
	{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
};

static const u8 zmako_length_tables[16] = {
	0, 1, 2, 8, 1, 2, 3, 9, 2, 3, 4, 10, 8, 9, 10, 16
};
#endif

static void zmako_release_params(struct zcomp_params *params) {}
static int zmako_setup_params(struct zcomp_params *params) { return 0; }
static void zmako_destroy(struct zcomp_ctx *ctx) {}

static int zmako_create(struct zcomp_params *params, struct zcomp_ctx *ctx)
{
	ctx->context = NULL;
	return 0;
}

static int zmako_compress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			  struct zcomp_req *req)
{
	const u64 *src_words = (const u64 *)req->src;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	u64 *tags_out = (u64 *)req->dst;
	u8 *payload_base = req->dst + tag_area_size;

	u32 payload_offset = 0;
	u64 dict[65] = {0};

#ifdef USE_NEON_ZMAKO
	kernel_neon_begin();
	for (int i = 0; i < words_per_page; i += 32) {
		u64 current_tags = 0;
		for (int j = 0; j < 32; j += 4) {
			__builtin_prefetch(&src_words[i + j + 16], 0, 0);

			uint64x2_t w01 = vld1q_u64((const unsigned long *)&src_words[i + j]);
			uint64x2_t w23 = vld1q_u64((const unsigned long *)&src_words[i + j + 2]);

			u64 w0 = vgetq_lane_u64(w01, 0);
			u64 w1 = vgetq_lane_u64(w01, 1);
			u64 w2 = vgetq_lane_u64(w23, 0);
			u64 w3 = vgetq_lane_u64(w23, 1);
			
			u8 h0 = (w0 * HASH_MULTIPLIER) >> 58;
			u64 d0 = dict[h0];
			u8 s0 = (w0 == 0) ? 0 : ((d0 == w0) ? 1 : ((((w0 ^ d0) >> 8) == 0) ? 2 : 3));
			dict[h0 | ((w0 == 0) << 6)] = w0;
			
			u8 h1 = (w1 * HASH_MULTIPLIER) >> 58;
			u64 d1 = dict[h1];
			u8 s1 = (w1 == 0) ? 0 : ((d1 == w1) ? 1 : ((((w1 ^ d1) >> 8) == 0) ? 2 : 3));
			dict[h1 | ((w1 == 0) << 6)] = w1;
			
			u8 h2 = (w2 * HASH_MULTIPLIER) >> 58;
			u64 d2 = dict[h2];
			u8 s2 = (w2 == 0) ? 0 : ((d2 == w2) ? 1 : ((((w2 ^ d2) >> 8) == 0) ? 2 : 3));
			dict[h2 | ((w2 == 0) << 6)] = w2;
			u8 h3 = (w3 * HASH_MULTIPLIER) >> 58;
			u64 d3 = dict[h3];
			u8 s3 = (w3 == 0) ? 0 : ((d3 == w3) ? 1 : ((((w3 ^ d3) >> 8) == 0) ? 2 : 3));
			dict[h3 | ((w3 == 0) << 6)] = w3;

			u8 cs01 = (s0 << 2) | s1;
			u8 cs23 = (s2 << 2) | s3;

			current_tags |= ((u64)s0 << (j * 2));
			current_tags |= ((u64)s1 << (j * 2 + 2));
			current_tags |= ((u64)s2 << (j * 2 + 4));
			current_tags |= ((u64)s3 << (j * 2 + 6));

			uint8x16_t perm01 = vld1q_u8(zmako_perm_tables[cs01]);
			uint8x16_t perm23 = vld1q_u8(zmako_perm_tables[cs23]);

			uint8x16_t words_reg01 = vreinterpretq_u8_u64(w01);
			uint8x16_t words_reg23 = vreinterpretq_u8_u64(w23);

			uint16_t hashes01 = h0 | ((u16)h1 << 8);
			uint16_t hashes23 = h2 | ((u16)h3 << 8);

			uint8x16_t hash_reg01 = vreinterpretq_u8_u16(vdupq_n_u16(hashes01));
			uint8x16_t hash_reg23 = vreinterpretq_u8_u16(vdupq_n_u16(hashes23));

			uint8x16x2_t table01 = { words_reg01, hash_reg01 };
			uint8x16x2_t table23 = { words_reg23, hash_reg23 };

			uint8x16_t packed01 = vqtbl2q_u8(table01, perm01);
			vst1q_u8(payload_base + payload_offset, packed01);
			payload_offset += zmako_length_tables[cs01];

			uint8x16_t packed23 = vqtbl2q_u8(table23, perm23);
			vst1q_u8(payload_base + payload_offset, packed23);
			payload_offset += zmako_length_tables[cs23];
		}
		*tags_out++ = current_tags;
	}
	kernel_neon_end();
#else
	for (int i = 0; i < words_per_page; i += 32) {
		u64 current_tags = 0;
		for (int j = 0; j < 32; j++) {
			u64 word = src_words[i + j];
			u8 hash = (word * HASH_MULTIPLIER) >> 58;
			u64 d_word = dict[hash];

			u8 state = (word == 0) ? 0 : ((d_word == word) ? 1 : ((((word ^ d_word) >> 8) == 0) ? 2 : 3));
			u64 out_val = (state == 3) ? word :
			              (state == 2) ? (hash | ((word & 0xFF) << 8)) :
			              (state == 1) ? hash : 0;

			put_unaligned(out_val, (u64 *)(payload_base + payload_offset));
			payload_offset += payload_step[state];

			dict[hash | ((word == 0) << 6)] = word;
			current_tags |= ((u64)state << (j * 2));
		}
		*tags_out++ = current_tags;
	}
#endif

	put_unaligned(0ULL, (u64 *)(payload_base + payload_offset));
	put_unaligned(0ULL, (u64 *)(payload_base + payload_offset + 8));
	
	req->dst_len = tag_area_size + payload_offset + 16;
	return 0;
}

static int zmako_decompress(struct zcomp_params *params, struct zcomp_ctx *ctx,
			    struct zcomp_req *req)
{
	u64 *dst_words = (u64 *)req->dst;
	int words_per_page = PAGE_SIZE / 8;
	int tag_area_size = words_per_page * 2 / 8;

	const u64 *tags_in = (const u64 *)req->src;
	const u8 *payload = req->src + tag_area_size;

	u64 dict[65] = {0};

#ifdef USE_NEON_ZMAKO
	kernel_neon_begin();
	for (int i = 0; i < words_per_page; i += 32) {
		u64 current_tags = *tags_in++;
		for (int j = 0; j < 32; j += 4) {
			__builtin_prefetch(payload + 64, 0, 0);

			u8 s0 = (current_tags >> (j * 2)) & 3;
			u8 s1 = (current_tags >> (j * 2 + 2)) & 3;
			u8 s2 = (current_tags >> (j * 2 + 4)) & 3;
			u8 s3 = (current_tags >> (j * 2 + 6)) & 3;
			
			u8 cs01 = (s0 << 2) | s1;
			u8 cs23 = (s2 << 2) | s3;

			uint8x16_t packed01 = vld1q_u8(payload);
			uint8x16_t unpacked01 = vqtbl1q_u8(packed01, vld1q_u8(zmako_unperm_tables[cs01]));
			payload += zmako_length_tables[cs01];

			uint8x16_t packed23 = vld1q_u8(payload);
			uint8x16_t unpacked23 = vqtbl1q_u8(packed23, vld1q_u8(zmako_unperm_tables[cs23]));
			payload += zmako_length_tables[cs23];

			uint64x2_t u64_01 = vreinterpretq_u64_u8(unpacked01);
			uint64x2_t u64_23 = vreinterpretq_u64_u8(unpacked23);

			u64 w0_raw = vgetq_lane_u64(u64_01, 0);
			u64 w1_raw = vgetq_lane_u64(u64_01, 1);
			u64 w2_raw = vgetq_lane_u64(u64_23, 0);
			u64 w3_raw = vgetq_lane_u64(u64_23, 1);

			u64 d0 = dict[w0_raw & DICT_MASK];
			u64 out0 = (s0 == 3) ? w0_raw :
			           (s0 == 2) ? ((d0 & 0xFFFFFFFFFFFFFF00ULL) | ((w0_raw >> 8) & 0xFF)) :
			           (s0 == 1) ? d0 : 0;
           dst_words[i + j + 0] = out0;
           dict[((out0 * HASH_MULTIPLIER) >> 58) | ((out0 == 0) << 6)] = out0;
           
           u64 d1 = dict[w1_raw & DICT_MASK];
           u64 out1 = (s1 == 3) ? w1_raw :
			           (s1 == 2) ? ((d1 & 0xFFFFFFFFFFFFFF00ULL) | ((w1_raw >> 8) & 0xFF)) :
			           (s1 == 1) ? d1 : 0;
           dst_words[i + j + 1] = out1;
           dict[((out1 * HASH_MULTIPLIER) >> 58) | ((out1 == 0) << 6)] = out1;
           
           u64 d2 = dict[w2_raw & DICT_MASK];
           u64 out2 = (s2 == 3) ? w2_raw :
			           (s2 == 2) ? ((d2 & 0xFFFFFFFFFFFFFF00ULL) | ((w2_raw >> 8) & 0xFF)) :
			           (s2 == 1) ? d2 : 0;
           dst_words[i + j + 2] = out2;
           dict[((out2 * HASH_MULTIPLIER) >> 58) | ((out2 == 0) << 6)] = out2;
           
           u64 d3 = dict[w3_raw & DICT_MASK];
           u64 out3 = (s3 == 3) ? w3_raw :
			           (s3 == 2) ? ((d3 & 0xFFFFFFFFFFFFFF00ULL) | ((w3_raw >> 8) & 0xFF)) :
			           (s3 == 1) ? d3 : 0;
           dst_words[i + j + 3] = out3;
           dict[((out3 * HASH_MULTIPLIER) >> 58) | ((out3 == 0) << 6)] = out3;
		}
	}
	kernel_neon_end();
#else
	for (int i = 0; i < words_per_page; i += 32) {
		u64 current_tags = *tags_in++;
		for (int j = 0; j < 32; j++) {
			u8 state = (current_tags >> (j * 2)) & 0x03;
			
			u64 p_val = get_unaligned((const u64 *)payload);
			u8 hash = p_val & DICT_MASK;
			u8 delta = (p_val >> 8) & 0xFF;
			
			u64 d_val = dict[hash];
			
			u64 out_word = (state == 3) ? p_val :
			               (state == 2) ? ((d_val & 0xFFFFFFFFFFFFFF00ULL) | delta) :
			               (state == 1) ? d_val : 0;
			
			dst_words[i + j] = out_word;
			
			dict[((out_word * HASH_MULTIPLIER) >> 58) | ((out_word == 0) << 6)] = out_word;
			
			payload += payload_step[state];
		}
	}
#endif

	return 0;
}

const struct zcomp_ops backend_zmako = {
	.compress	= zmako_compress,
	.decompress	= zmako_decompress,
	.create_ctx	= zmako_create,
	.destroy_ctx	= zmako_destroy,
	.setup_params	= zmako_setup_params,
	.release_params	= zmako_release_params,
	.name		= "zmako",
};
